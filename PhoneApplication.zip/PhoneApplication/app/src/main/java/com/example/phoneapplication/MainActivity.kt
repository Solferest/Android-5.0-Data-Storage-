package com.example.phoneapplication

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope

import kotlinx.coroutines.launch
import com.example.phoneapplication.repository.ContactRep
import com.example.phoneapplication.repository.NoteRep
import com.example.phoneapplication.model.Contact
import com.example.phoneapplication.model.Note
import com.example.phoneapplication.ui.theme.PhoneApplicationTheme


class MainActivity : ComponentActivity() {

    private lateinit var contactRep: ContactRep
    private lateinit var noteRep: NoteRep

    private var contacts by mutableStateOf(emptyList<Contact>())
    private var notes by mutableStateOf(emptyList<Note>())

    private var contactSelected by mutableStateOf(0L)
    private var isEditDialogVisible by mutableStateOf(false)


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        contactRep = ContactRep(this)
        noteRep = NoteRep(this)

        importContacts()
        importNotes()

        setContent {
            PhoneApplicationTheme(content = {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFFB3DEFF),
                ) {
                    MainScreen(context = this)
                }
            }
            )
        }
        // Check and request contacts permission at runtime
        checkAndRequestContactsPermission()
    }

    private var isContactsImported by mutableStateOf(false)
    private var isNotesImported by mutableStateOf(false)


    private fun importContacts() {
        if (!isContactsImported) {
            lifecycleScope.launch {
                contactRep.importContacts()
                contacts = contactRep.getAllContacts()
            }
            isContactsImported = true
        }
    }

    private fun importNotes(){
        if(!isNotesImported){
            lifecycleScope.launch {
                notes = noteRep.getAllNotes()
            }
            isNotesImported = true;
        }
    }

    private val READ_CONTACTS_PERMISSION_REQUEST_CODE = 1001
    private val WRITE_CONTACTS_PERMISSION_REQUEST_CODE = 1002

    private fun checkAndRequestContactsPermission() {

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_CONTACTS
            ) != PackageManager.PERMISSION_GRANTED
        ) {

            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.READ_CONTACTS),
                READ_CONTACTS_PERMISSION_REQUEST_CODE
            )
        } else {

            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.WRITE_CONTACTS
                ) != PackageManager.PERMISSION_GRANTED
            ) {

                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.WRITE_CONTACTS),
                    WRITE_CONTACTS_PERMISSION_REQUEST_CODE
                )
            } else {

                importContacts()
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        when (requestCode) {
            READ_CONTACTS_PERMISSION_REQUEST_CODE,
            WRITE_CONTACTS_PERMISSION_REQUEST_CODE -> {

                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    importContacts()
                } else {

                }
            }
            else -> {
                super.onRequestPermissionsResult(requestCode, permissions, grantResults)
            }
        }
    }


    @Composable
    private fun MainScreen(context: Context) {
        Text(
            text = stringResource(R.string.contacts),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Column {
            LazyColumn(
                modifier = Modifier
                    .padding(16.dp)
                    .weight(1f)
            ) {
                item {

                    Spacer(modifier = Modifier.height(50.dp))
                }
                items(contacts.size) { index ->
                    val contact = contacts[index]
                    val note = notes.find { note -> note.contactId == contact.id }
                    ContactItem(
                        contact = contact,
                        note = note,
                        onEditClick = {
                            contactSelected = contact.id
                            isEditDialogVisible = true
                        },
                        onDeleteClick = {
                            lifecycleScope.launch {
                                val note = noteRep.getNoteByContactId(contact.id)
                                if(note != null){
                                    noteRep.deleteNote(note)
                                }
                                notes=noteRep.getAllNotes()
                            }
                        }
                    )
                }
            }

            if (isEditDialogVisible) {
                val note = notes.find { note -> note.contactId == contactSelected }
                EditContact(
                    oldNote = note?.description ?: "Нет",
                    onDismiss = {
                        isEditDialogVisible = false
                    },
                    onSave = {newNote: String ->
                        lifecycleScope.launch {
                            val idNote = noteRep.getNoteIdByContactId(contactSelected)
                            if(idNote != null){
                                val editedNote = Note(
                                    id = idNote,
                                    description = newNote,
                                    contactId = contactSelected
                                )
                                noteRep.updateNote(editedNote)
                            }
                            else{
                                val note = Note(
                                    description = newNote,
                                    contactId = contactSelected
                                )
                                noteRep.insertNote(note)
                            }
                            notes = noteRep.getAllNotes();
                        }
                        isEditDialogVisible = false
                    }
                )
            }
        }
    }


    @Composable
    private fun ContactItem(
        contact: Contact,
        note: Note?,
        onEditClick: () -> Unit,
        onDeleteClick: () -> Unit
    ) {

        val desc: String = note?.description ?: stringResource(R.string.note_empty)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
        ) {
            Text(
                text = "Имя: ${contact.name}\nНомер: ${contact.phoneNumber}\nЗаметка: ${desc}",
                style = MaterialTheme.typography.headlineSmall,
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                ContactActionButton(Icons.Default.Edit) {
                    onEditClick()
                }
                ContactActionButton(Icons.Default.Delete) {
                    onDeleteClick()
                }
            }
        }
    }


    @Composable
    private fun ContactActionButton(icon: ImageVector, onClick: () -> Unit) {
        IconButton(
            onClick = onClick,
            modifier = Modifier.size(40.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color(0xFF000000),
            )
        }
    }


    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun EditContact(
        oldNote: String,
        onDismiss: () -> Unit,
        onSave: (newNote: String) -> Unit

    ) {
        var newNote by remember { mutableStateOf(TextFieldValue(oldNote)) }

        AlertDialog(
            onDismissRequest = { onDismiss() },
            title = { Text(stringResource(R.string.note_edit)) },
            text = {
                Column {
                    TextField(
                        value = newNote,
                        onValueChange = { newNote = it },
                        label = { Text(stringResource(R.string.create_note)) }
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSave(newNote.text)
                        onDismiss()
                    }
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = null,
                        tint = Color(0xFFFFFFFF),
                    )
                    Color(0xFFB3DEFF)
                    Text(stringResource(R.string.save))
                }
            },
            dismissButton = {
                Button(
                    onClick = { onDismiss() }
                ) {
                    Icon(
                        imageVector = Icons.Default.Clear,
                        contentDescription = null,
                        tint = Color(0xFFFFFFFF),
                    )
                    Color(0xFFB3DEFF)
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }
}